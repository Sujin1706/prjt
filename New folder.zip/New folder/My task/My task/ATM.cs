﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_task
{
    abstract class ATM
    {
        public int PinNo_DM;
        public long CurrentBalance = 0, DepositAmnt_DM, WithdrawAmnt_DM, TotalBal, AvailableBal;
        //Absract Method
        public abstract bool pinNum_MF();
        //Non Absract Method
        public long Deposit_MF()
        {
            if(DepositAmnt_DM>=100)
            {
                TotalBal = CurrentBalance + DepositAmnt_DM;
                MessageBox.Show("Credited");
            }
            else
            {
                MessageBox.Show("Minimum Deposit amount is 100" + "\n" + "Please Enter a valid amount:)");
            }
            return TotalBal;
        }
        public long withdraw_MF()
        {
            if(WithdrawAmnt_DM<=TotalBal)
            {
                if(WithdrawAmnt_DM>=100)
                {
                    AvailableBal = TotalBal - WithdrawAmnt_DM;
                    MessageBox.Show("Debited");
                }
                else
                {
                    MessageBox.Show("Minimum Withdraw amount is 100" + "\n" + "Please Enter a valid amount:)");
                }
            }
            else
            {
                MessageBox.Show("Insufficiant Balance");
            }
            return AvailableBal;
        }
    }
    class TRANSACTION:ATM
    {
        public override bool pinNum_MF()
        {
            bool validating = false;
            if(PinNo_DM==123)
            {
                validating = true;
            }
            return validating;
        }
    }
}
