﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_task
{
    public partial class Form1 : Form
    {
        int Pn;
        long DAmnt, WDrawAmnt;
        TRANSACTION obj = new TRANSACTION();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Selectcombo.Visible = false;
            Banking.Visible = false;
            DepositGB.Visible = false;
            WithdrawGB.Visible = false;
        }

        private void Selectcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Selectcombo.Text == "Deposit")
            {
                DepositGB.Visible = true;
                WithdrawGB.Visible = false;
            }
            else if (Selectcombo.Text == "Withdraw")
            {
                DepositGB.Visible = false;
                WithdrawGB.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select the option");
            }
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            if(PinNoTxtBox.Text!="")
            {
                Pn = int.Parse(PinNoTxtBox.Text);
                obj.PinNo_DM = Pn;
                bool validated = obj.pinNum_MF();
                if(validated==true)
                {
                    MessageBox.Show("Welcome User");
                    Selectcombo.Visible = true;
                    Banking.Visible = true;
                }
                else
                {
                    MessageBox.Show("Invalid Pin Number");
                }
            }
            else
            {
                MessageBox.Show("Please Enter the Pin Number");
            }
        }

        private void DepositBtn_Click(object sender, EventArgs e)
        {
            if(DepositTxtBox.Text!="")
            {
                DAmnt = long.Parse(DepositTxtBox.Text);
                obj.DepositAmnt_DM = DAmnt;
                long TOTALBALANCE = obj.Deposit_MF();
                MessageBox.Show("Total Balance :" + TOTALBALANCE);
            }
            else
            {
                MessageBox.Show("Please Put the amount");
            }
        }

        private void WithdrawBtn_Click(object sender, EventArgs e)
        {
            if(WithdrawTxtBox.Text!="")
            {
                WDrawAmnt = long.Parse(WithdrawTxtBox.Text);
                obj.WithdrawAmnt_DM = WDrawAmnt;
                long AVAILABLEBALANCE = obj.withdraw_MF();
                MessageBox.Show("Available Balance :" + AVAILABLEBALANCE);
            }
            else
            {
                MessageBox.Show("Please Enter the amount");
            }
        }    
    }
}
