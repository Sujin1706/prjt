﻿namespace My_task
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PinNoTxtBox = new System.Windows.Forms.TextBox();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.Selectcombo = new System.Windows.Forms.ComboBox();
            this.DepositGB = new System.Windows.Forms.GroupBox();
            this.DepositBtn = new System.Windows.Forms.Button();
            this.DepositTxtBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.WithdrawGB = new System.Windows.Forms.GroupBox();
            this.WithdrawBtn = new System.Windows.Forms.Button();
            this.WithdrawTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Banking = new System.Windows.Forms.Label();
            this.DepositGB.SuspendLayout();
            this.WithdrawGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // PinNoTxtBox
            // 
            this.PinNoTxtBox.Location = new System.Drawing.Point(26, 42);
            this.PinNoTxtBox.Name = "PinNoTxtBox";
            this.PinNoTxtBox.Size = new System.Drawing.Size(197, 20);
            this.PinNoTxtBox.TabIndex = 1;
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(26, 69);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(75, 23);
            this.SubmitBtn.TabIndex = 2;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // Selectcombo
            // 
            this.Selectcombo.FormattingEnabled = true;
            this.Selectcombo.Items.AddRange(new object[] {
            "Deposit",
            "Withdraw"});
            this.Selectcombo.Location = new System.Drawing.Point(26, 127);
            this.Selectcombo.Name = "Selectcombo";
            this.Selectcombo.Size = new System.Drawing.Size(121, 21);
            this.Selectcombo.TabIndex = 3;
            this.Selectcombo.SelectedIndexChanged += new System.EventHandler(this.Selectcombo_SelectedIndexChanged);
            // 
            // DepositGB
            // 
            this.DepositGB.Controls.Add(this.DepositBtn);
            this.DepositGB.Controls.Add(this.DepositTxtBox);
            this.DepositGB.Controls.Add(this.label2);
            this.DepositGB.Location = new System.Drawing.Point(26, 165);
            this.DepositGB.Name = "DepositGB";
            this.DepositGB.Size = new System.Drawing.Size(229, 156);
            this.DepositGB.TabIndex = 4;
            this.DepositGB.TabStop = false;
            this.DepositGB.Text = "Deposit Section";
            // 
            // DepositBtn
            // 
            this.DepositBtn.Location = new System.Drawing.Point(67, 82);
            this.DepositBtn.Name = "DepositBtn";
            this.DepositBtn.Size = new System.Drawing.Size(75, 23);
            this.DepositBtn.TabIndex = 2;
            this.DepositBtn.Text = "Deposit";
            this.DepositBtn.UseVisualStyleBackColor = true;
            this.DepositBtn.Click += new System.EventHandler(this.DepositBtn_Click);
            // 
            // DepositTxtBox
            // 
            this.DepositTxtBox.Location = new System.Drawing.Point(0, 36);
            this.DepositTxtBox.Name = "DepositTxtBox";
            this.DepositTxtBox.Size = new System.Drawing.Size(197, 20);
            this.DepositTxtBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-3, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter the amount";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter the pin number";
            // 
            // WithdrawGB
            // 
            this.WithdrawGB.Controls.Add(this.WithdrawBtn);
            this.WithdrawGB.Controls.Add(this.WithdrawTxtBox);
            this.WithdrawGB.Controls.Add(this.label3);
            this.WithdrawGB.Location = new System.Drawing.Point(339, 165);
            this.WithdrawGB.Name = "WithdrawGB";
            this.WithdrawGB.Size = new System.Drawing.Size(229, 156);
            this.WithdrawGB.TabIndex = 6;
            this.WithdrawGB.TabStop = false;
            this.WithdrawGB.Text = "Withdraw Section";
            // 
            // WithdrawBtn
            // 
            this.WithdrawBtn.Location = new System.Drawing.Point(64, 82);
            this.WithdrawBtn.Name = "WithdrawBtn";
            this.WithdrawBtn.Size = new System.Drawing.Size(75, 23);
            this.WithdrawBtn.TabIndex = 2;
            this.WithdrawBtn.Text = "Withdraw";
            this.WithdrawBtn.UseVisualStyleBackColor = true;
            this.WithdrawBtn.Click += new System.EventHandler(this.WithdrawBtn_Click);
            // 
            // WithdrawTxtBox
            // 
            this.WithdrawTxtBox.Location = new System.Drawing.Point(0, 36);
            this.WithdrawTxtBox.Name = "WithdrawTxtBox";
            this.WithdrawTxtBox.Size = new System.Drawing.Size(197, 20);
            this.WithdrawTxtBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-3, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Enter the amount";
            // 
            // Banking
            // 
            this.Banking.AutoSize = true;
            this.Banking.Location = new System.Drawing.Point(23, 111);
            this.Banking.Name = "Banking";
            this.Banking.Size = new System.Drawing.Size(46, 13);
            this.Banking.TabIndex = 7;
            this.Banking.Text = "Banking";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 429);
            this.Controls.Add(this.Banking);
            this.Controls.Add(this.WithdrawGB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DepositGB);
            this.Controls.Add(this.Selectcombo);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.PinNoTxtBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DepositGB.ResumeLayout(false);
            this.DepositGB.PerformLayout();
            this.WithdrawGB.ResumeLayout(false);
            this.WithdrawGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PinNoTxtBox;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.ComboBox Selectcombo;
        private System.Windows.Forms.GroupBox DepositGB;
        private System.Windows.Forms.Button DepositBtn;
        private System.Windows.Forms.TextBox DepositTxtBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox WithdrawGB;
        private System.Windows.Forms.Button WithdrawBtn;
        private System.Windows.Forms.TextBox WithdrawTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Banking;
    }
}

