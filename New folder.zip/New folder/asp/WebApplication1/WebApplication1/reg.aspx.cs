﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class reg : System.Web.UI.Page

    {
        SqlConnection cn= new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=bank;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btreg_Click(object sender, EventArgs e)
        {
            if(Page.IsValid){
            cn.Open();
            SqlCommand cm = new SqlCommand("insert1", cn);
            cm.Parameters.AddWithValue("aname", txname.Text);
            cm.Parameters.AddWithValue("anum", txnum.Text);
            cm.Parameters.AddWithValue("mob", txmob.Text);
            cm.Parameters.AddWithValue("branch", dlbranch.Text);
            cm.Parameters.AddWithValue("atype", rbsaving.Text);
            cm.Parameters.AddWithValue("uname", txuname.Text);
            cm.Parameters.AddWithValue("pass", txpwd. Text);
            cm.CommandType = CommandType.StoredProcedure;
            int i = cm.ExecuteNonQuery();
                Response.Write("<script>alert ('"+i+" user registered successfully')</script>)");
                cn.Close();
            }
        }
    }
}