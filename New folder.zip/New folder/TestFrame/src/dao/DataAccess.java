/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ACCORD
 */
public class DataAccess {
    
    Connection cn;
    PreparedStatement pst;
    PreparedStatement pst1;
    ResultSet result;

    public DataAccess() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            cn= DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
            pst=cn.prepareStatement("insert into employee values(?,?,?,?,?,?,?)");
            pst1=cn.prepareStatement("select * from employee where eid=?");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public int saveRecord(String eid,String name,String gender,String mobile,String mailid,String address,String quali){
        int count=0;
        try{
            pst.setString(1, eid);
            pst.setString(2, name);
            pst.setString(3, gender);
            pst.setString(4, mobile);
            pst.setString(5, mailid);
            pst.setString(6, address);
            pst.setString(7, quali);
            count=pst.executeUpdate();
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        return count;
    }
    
    public String[] search(String eid){
        String[] array = new String[7];
        array[0]="NOT_FOUND";
        try{
            pst1.setString(1, eid);
            result=pst1.executeQuery();
            if(result.next()==true){
               
                array[0]=result.getString(1);
                array[1]=result.getString(2);
                array[2]=result.getString(3);
                array[3]=result.getString(4);
                array[4]=result.getString(5);
                array[5]=result.getString(6);
                array[6]=result.getString(7);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return  array;
    }
    
    
}
