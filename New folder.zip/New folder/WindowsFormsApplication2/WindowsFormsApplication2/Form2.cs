﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=mylib;Integrated Security=True");
        
        
            private void button1_Click(object sender, EventArgs e)
        {
                cn.Open();

                SqlCommand cmd= new SqlCommand("insert into bstore values ('" + txtname.Text + "','" + txtaut.Text + "','" + cbcty.Text + "'," + txtyear.Text + "," + txtqty.Text + ")", cn);
                int i = cmd.ExecuteNonQuery();
                MessageBox.Show(i + "    Book Added ");
                cn.Close();
                Form2_Load(sender, e);
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            cn.Open();
            SqlCommand cmd=new SqlCommand("select * from bstore", cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];



            SqlCommand cmd1 = new SqlCommand("select bid, bname from bstore", cn);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            cbsel.DataSource = ds1.Tables[0];
            cbsel.DisplayMember = "bname";
            cbsel.ValueMember = "bid";

                       cn.Close();
           
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cn.Open();

            SqlCommand cmd = new SqlCommand("delete from bstore where bid=  " + cbsel.SelectedValue + "", cn);
            int i = cmd.ExecuteNonQuery();
            MessageBox.Show("book removed");
            cn.Close();
            Form2_Load(sender, e);
        }

        private void bts_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select *from bstore where bid=" + cbsel.SelectedValue + "", cn);
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();

            txtname.Text = dr[1].ToString();
          txtaut.Text = dr[2].ToString();
            cbcty.Text = dr[3].ToString();
            txtyear.Text = dr[4].ToString();
            txtqty.Text = dr[5].ToString();
            cn.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("update bstore set bname='" + txtname.Text + "',author='" + txtaut.Text + "',catagory='" + cbcty.Text + "',year=" + txtyear.Text + ",qty=" + txtqty.Text + "where bid="+cbsel.SelectedValue+"", cn);
             cmd.ExecuteNonQuery();
            MessageBox.Show( "    Book updated");
            cn.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select count(bname) from bstore", cn);
            int i = Convert.ToInt32(cmd.ExecuteScalar());
            MessageBox.Show(i + "   are in our library");
            cn.Close();

        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form2_BackgroundImageChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            Form3 f = new Form3();
            f.Show();
        }
        }   
}
