﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApplication2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=mylib;Integrated Security=True");

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from bentry", cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            SqlCommand cmd1 = new SqlCommand("select bid, bname from bstore", cn);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            cbname.DataSource = ds1.Tables[0];
            cbname.DisplayMember = "bname";
            cbname.ValueMember = "bid";

            SqlCommand cm = new SqlCommand("select count(eno) from bentry", cn);
            int i = Convert.ToInt32(cm.ExecuteScalar())+1;
            txent.Text = Convert.ToString(i);
         // txdat.Text = Convert.ToString(get;
           // txdat.Text = DateTime.Now.ToShortDateString();
            txdat.Text = DateTime.Now.ToString();
            //txdat.Text = DateTimePickerFormat.Short.ToString();

           // DateTime myDateTime = DateTime.Now;
            //string sqlFormattedDate = myDateTime.Date.ToString("yyyy-MM-dd");
            //txdat.Text = sqlFormattedDate;
            cn.Close();
            //Form4_Load(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cn.Open();

            SqlCommand cmd = new SqlCommand("insert into bentry (eno, cname,bname,author,qty,entdat,mob)values (" + txent.Text + ",'" + txcus.Text + "','" + cbname.Text + "','" + txaut.Text + "'," + txqty.Text + ",'" + txdat.Text + "'," + txmob.Text + ")", cn);
            int i = cmd.ExecuteNonQuery();
            MessageBox.Show("Book Enterd ");
            cn.Close();
            Form4_Load(sender, e);
        }

        private void cbname_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select *from bstore where bid=" + cbname.SelectedValue + "", cn);
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();

            txaut.Text = dr["author"].ToString();
            txqty.Text = dr["qty"].ToString();

            cn.Close();
        }
    }
}
