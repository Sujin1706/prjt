﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=mylib;Integrated Security=True");

        private void Form5_Load(object sender, EventArgs e)
        {
            txdate.Text = DateTime.Now.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select *from bentry where eno=" + txent.Text + "", cn);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                txbook.Text = dr["bname"].ToString();
                txaut.Text = dr["author"].ToString();
                txmob.Text = dr["mob"].ToString();
                txqty.Text = dr["qty"].ToString();
            }
            else
            {
                MessageBox.Show("No Records Found");
            }
            cn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            cn.Open();
            SqlCommand cmd = new SqlCommand("update bentry set ret='" + txdate.Text + "'", cn);
            int i = cmd.ExecuteNonQuery();
            MessageBox.Show(" Book retruned");
            SqlCommand cmd2 = new SqlCommand("delete from bentry where eno=  " + txent.Text + "", cn);
            int ii = cmd2.ExecuteNonQuery();
            
            cn.Close();
            
        }
    }
}
