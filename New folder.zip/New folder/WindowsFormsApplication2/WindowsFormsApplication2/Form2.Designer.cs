﻿namespace WindowsFormsApplication2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtaut = new System.Windows.Forms.TextBox();
            this.txtyear = new System.Windows.Forms.TextBox();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cbcty = new System.Windows.Forms.ComboBox();
            this.cbsel = new System.Windows.Forms.ComboBox();
            this.bstoreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mylibDataSet = new WindowsFormsApplication2.mylibDataSet();
            this.bstoreBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mylibDataSet1 = new WindowsFormsApplication2.mylibDataSet1();
            this.add = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.remove = new System.Windows.Forms.Button();
            this.count = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bstoreTableAdapter = new WindowsFormsApplication2.mylibDataSetTableAdapters.bstoreTableAdapter();
            this.bstoreTableAdapter1 = new WindowsFormsApplication2.mylibDataSet1TableAdapters.bstoreTableAdapter();
            this.bts = new System.Windows.Forms.Button();
            this.locker = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bstoreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mylibDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bstoreBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mylibDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(119, 44);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(167, 20);
            this.txtname.TabIndex = 0;
            // 
            // txtaut
            // 
            this.txtaut.Location = new System.Drawing.Point(119, 106);
            this.txtaut.Name = "txtaut";
            this.txtaut.Size = new System.Drawing.Size(167, 20);
            this.txtaut.TabIndex = 1;
            // 
            // txtyear
            // 
            this.txtyear.Location = new System.Drawing.Point(119, 213);
            this.txtyear.Name = "txtyear";
            this.txtyear.Size = new System.Drawing.Size(167, 20);
            this.txtyear.TabIndex = 2;
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(119, 270);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(167, 20);
            this.txtqty.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(304, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(414, 251);
            this.dataGridView1.TabIndex = 4;
            // 
            // cbcty
            // 
            this.cbcty.FormattingEnabled = true;
            this.cbcty.Items.AddRange(new object[] {
            "Journal",
            "Comics",
            "Referance",
            "Culture",
            "Sports"});
            this.cbcty.Location = new System.Drawing.Point(119, 156);
            this.cbcty.Name = "cbcty";
            this.cbcty.Size = new System.Drawing.Size(167, 21);
            this.cbcty.TabIndex = 5;
            // 
            // cbsel
            // 
            this.cbsel.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bstoreBindingSource, "bid", true));
            this.cbsel.DataSource = this.bstoreBindingSource1;
            this.cbsel.DisplayMember = "bname";
            this.cbsel.FormattingEnabled = true;
            this.cbsel.Location = new System.Drawing.Point(382, 308);
            this.cbsel.Name = "cbsel";
            this.cbsel.Size = new System.Drawing.Size(220, 21);
            this.cbsel.TabIndex = 6;
            this.cbsel.ValueMember = "bid";
            this.cbsel.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // bstoreBindingSource
            // 
            this.bstoreBindingSource.DataMember = "bstore";
            this.bstoreBindingSource.DataSource = this.mylibDataSet;
            // 
            // mylibDataSet
            // 
            this.mylibDataSet.DataSetName = "mylibDataSet";
            this.mylibDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bstoreBindingSource1
            // 
            this.bstoreBindingSource1.DataMember = "bstore";
            this.bstoreBindingSource1.DataSource = this.mylibDataSet1;
            // 
            // mylibDataSet1
            // 
            this.mylibDataSet1.DataSetName = "mylibDataSet1";
            this.mylibDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // add
            // 
            this.add.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.add.Location = new System.Drawing.Point(21, 425);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(87, 23);
            this.add.TabIndex = 7;
            this.add.Text = "Add Book";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.button1_Click);
            // 
            // update
            // 
            this.update.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.update.Location = new System.Drawing.Point(137, 425);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(87, 23);
            this.update.TabIndex = 8;
            this.update.Text = "Update book";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.button2_Click);
            // 
            // remove
            // 
            this.remove.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.remove.Location = new System.Drawing.Point(256, 425);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(87, 23);
            this.remove.TabIndex = 9;
            this.remove.Text = "Remove Book";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.button3_Click);
            // 
            // count
            // 
            this.count.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.count.Location = new System.Drawing.Point(382, 425);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(87, 23);
            this.count.TabIndex = 10;
            this.count.Text = "Book count";
            this.count.UseVisualStyleBackColor = true;
            this.count.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Book Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Author";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Catagory";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Quantity";
            // 
            // bstoreTableAdapter
            // 
            this.bstoreTableAdapter.ClearBeforeFill = true;
            // 
            // bstoreTableAdapter1
            // 
            this.bstoreTableAdapter1.ClearBeforeFill = true;
            // 
            // bts
            // 
            this.bts.Location = new System.Drawing.Point(630, 308);
            this.bts.Name = "bts";
            this.bts.Size = new System.Drawing.Size(78, 21);
            this.bts.TabIndex = 16;
            this.bts.Text = "Search";
            this.bts.UseVisualStyleBackColor = true;
            this.bts.Click += new System.EventHandler(this.bts_Click);
            // 
            // locker
            // 
            this.locker.Location = new System.Drawing.Point(493, 425);
            this.locker.Name = "locker";
            this.locker.Size = new System.Drawing.Size(108, 22);
            this.locker.TabIndex = 17;
            this.locker.Text = "Hidden Books";
            this.locker.UseVisualStyleBackColor = true;
            this.locker.Click += new System.EventHandler(this.button5_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(730, 476);
            this.Controls.Add(this.locker);
            this.Controls.Add(this.bts);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.count);
            this.Controls.Add(this.remove);
            this.Controls.Add(this.update);
            this.Controls.Add(this.add);
            this.Controls.Add(this.cbsel);
            this.Controls.Add(this.cbcty);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.txtyear);
            this.Controls.Add(this.txtaut);
            this.Controls.Add(this.txtname);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "BOOK STOCK ENTRY";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.BackgroundImageChanged += new System.EventHandler(this.Form2_BackgroundImageChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form2_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bstoreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mylibDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bstoreBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mylibDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtaut;
        private System.Windows.Forms.TextBox txtyear;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cbcty;
        private System.Windows.Forms.ComboBox cbsel;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button remove;
        private System.Windows.Forms.Button count;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private mylibDataSet mylibDataSet;
        private System.Windows.Forms.BindingSource bstoreBindingSource;
        private mylibDataSetTableAdapters.bstoreTableAdapter bstoreTableAdapter;
        private mylibDataSet1 mylibDataSet1;
        private System.Windows.Forms.BindingSource bstoreBindingSource1;
        private mylibDataSet1TableAdapters.bstoreTableAdapter bstoreTableAdapter1;
        private System.Windows.Forms.Button bts;
        private System.Windows.Forms.Button locker;
    }
}