create database mylib
use mylib
create table bstore (bid int identity(100 ,1) primary key,bname varchar(30) unique not null ,author varchar(30) not null, catagory varchar(10), year int not null,qty int not null)
create table bbin (bid int not null,bname varchar(30)  not null unique,author varchar(30) not null, catagory varchar(10), year int not null,qty int not null)

select*from ta
select * from bstore
select * from bbin
use mylib
select* from sys.dataBASES
use mylib
drop table bstore
drop table bbin

create view ss
as
select bid, bname from bstore
drop view ss
select *from ss

--create trigger bookbin on bstore
--after delete
--0as
--begin
--declare @id int,@name varchar(30),@author varchar(30),@cata varchar(30), @year int, @qt int
--set @id=( select bid from deleted)
--set @name=( select bname from deleted)
--set @author=( select author from deleted)
--set @cata=( select catagory from deleted)
--set @year=( select year from deleted)
--set @qt=( select qty from deleted)--

--insert into bbin values(@id,'@name','@author','@cata',@year,@qt)
--end


create trigger bookbin on bstore
after delete
as
BEGIN
INSERT INTO bbin
SELECT * FROM DELETED
END
drop trigger bookbin
create trigger inst on bstore
instead of delete
as
begin
print 'hai'
end
delete from bstore where bid=103
create table ta(id int)
create trigger ii on bstore
after insert
as
begin
declare @eid int
set @eid=(select bid from inserted)
insert into ta values (@eid)
end
drop trigger inst
create table bentry (eno int  primary key,cname varchar(30)  not null , bname varchar(30),author varchar(30) not null,qty int not null, entdat date, mob bigint not null, ret date)
drop table bentry
drop database mylib
drop trigger bookbin
drop trigger bookAdd
select*from bentry