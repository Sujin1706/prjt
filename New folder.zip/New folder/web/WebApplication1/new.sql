select*from reg
use bank