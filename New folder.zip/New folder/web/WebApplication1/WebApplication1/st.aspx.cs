﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class st : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            { HiddenField1.Value = "0"; }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HiddenField1.Value = (Convert.ToInt32(HiddenField1.Value) + 1).ToString();
            int a = Convert.ToInt32(HiddenField1.Value);
            Label1.Text = a.ToString();
        }

        protected void HiddenField1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}