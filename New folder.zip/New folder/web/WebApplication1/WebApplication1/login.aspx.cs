﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=bank;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btsubmit_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cm = new SqlCommand("select * from reg  where  uname= '" + txid.Text + "' and pass= '" + txpwd.Text + "'", cn);
            
            SqlDataReader dr = cm.ExecuteReader();

            
             if (dr.Read()==true)
               
            {
                
                Session["nam"] = txid.Text;
                Session["db"] = dr[1].ToString();
                Response.Redirect("dashboard.aspx?");
            }
            else
            {
                Response.Write("<script>alert ('no')</script>)");
            } cn.Close();
        }

        protected void txpwd_TextChanged(object sender, EventArgs e)
        {

        }
    }
}