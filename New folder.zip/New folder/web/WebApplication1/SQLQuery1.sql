create database bank
use bank
create table reg(aname varchar(30) not null , anum varchar(10)not null unique, mob bigint not null unique, branch varchar(10) , atype varchar(10),uname varchar(20) not null unique, pass varchar(14) not null)
select * from reg
create procedure insert1  @aname varchar(30)  , @anum varchar(10), @mob bigint, @branch varchar(10) , @atype varchar(10),@uname varchar(20) , @pass varchar(14)
as 
begin
insert into reg values(@aname,@anum,@mob,@branch,@atype,@uname,@pass)
end