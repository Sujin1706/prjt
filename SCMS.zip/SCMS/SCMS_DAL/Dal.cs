﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using SCMS_Entity;
using SCMS_Exception;

namespace SCMS_DAL
{
    public class Dal
    {
        public static List<Customer> customers = new List<Customer>();
        public static List<Dealer> dealers = new List<Dealer>();
        public static List<Product> products = new List<Product>();
        public static List<ProductOrder> orders = new List<ProductOrder>();

        //public static string fileName = "eShoppy List";

        public static bool AddCustomer(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                customers.Add(customer);
                customerAdded = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerAdded;
        }
        public static bool UpdateCustomer(Customer customer)
        {
            bool customerUpdated = false;
            try
            {
                for (int i = 0; i < customers.Count; i++)
                {
                    if (customers[i].CustomerId == customer.CustomerId)
                    {
                        customers[i].OrganizationName = customer.OrganizationName;
                        customers[i].ContactPerson = customer.ContactPerson;
                        customers[i].ContactNumber = customer.ContactNumber;
                        customers[i].DeliveryAddress = customer.DeliveryAddress;
                        customers[i].OfficialEmail = customer.OfficialEmail;                       
                        customerUpdated = true;
                    }
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerUpdated;
        }
        public static bool DeleteCustomer(int CustId)
        {
            bool customerDeleted = false;
            try
            {
                Customer customer = customers.Find(s => s.CustomerId == CustId);
                if (customer != null)
                {
                    customers.Remove(customer);
                    customerDeleted = true;
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }
        public static Customer SearchCustomer(int CustId)
        {
            Customer customer = null;
            try
            {
                customer = customers.Find(s => s.CustomerId == CustId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customer;
        }
        public static List<Customer> RetrieveCustomer()
        {
            return customers;
        }
        public static bool SerializeCustomer()
        {
            bool customerSerialized = false;
            try
            {
                FileStream fs = new FileStream("customer.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, customers);
                fs.Close();
                customerSerialized = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerSerialized;
        }
        public static List<Customer> DeSerializeCustomer()
        {
            List<Customer> des = null;
            try
            {
                FileStream fs = new FileStream("customer.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Customer>;
                fs.Close();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return des;
        }
        public static bool RegisterAsDealer(Dealer dealer)
        {
            bool dealRegistered = false;
            try
            {
                dealers.Add(dealer);
                dealRegistered = true;
                
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return dealRegistered;
        }
        public static bool RegisterAsCustomer(Customer customer)
        {
            bool custRegistered = false;
            try
            {
                customers.Add(customer);
                custRegistered = true;            
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return custRegistered;
        }

        public static List<Customer> GetCustomers()
        {
            return customers;
        }


        public static bool AddDealer(Dealer deal)
        {
            bool dealAdded = false;
            try
            {
                dealers.Add(deal);
                dealAdded = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealAdded;
        }
        public static bool UpdateDealer(Dealer deal)
        {
            bool dealUpdated = false;
            try
            {
                for (int i = 0; i < dealers.Count; i++)
                {
                    if (dealers[i].DealerCode == deal.DealerCode)
                    {
                        dealers[i].OrganizationName = deal.OrganizationName;
                        dealers[i].ContactPerson = deal.ContactPerson;
                        dealers[i].ContactNumber = deal.ContactNumber;
                        dealers[i].DeliveryAddress = deal.DeliveryAddress;
                        dealers[i].WarehouseAddress = deal.WarehouseAddress;
                        dealers[i].OfficialEmail = deal.OfficialEmail;
                        dealUpdated = true;
                    }
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealUpdated;
        }
        public static bool DeleteDealer(int DealId)
        {
            bool dealDeleted = false;
            try
            {
                Dealer deal = dealers.Find(s => s.DealerCode == DealId);
                if (deal != null)
                {
                    dealers.Remove(deal);
                    dealDeleted = true;
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealDeleted;
        }
        public static Dealer SearchDealer(int DealId)
        {
            Dealer deal = null;
            try
            {
                deal = dealers.Find(s => s.DealerCode == DealId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return deal;
        }
        public static List<Dealer> RetrieveDealer()
        {
            return dealers;
        }
        public static bool SerializeDealer()
        {
            bool dealSerialized = false;
            try
            {
                FileStream fs = new FileStream("dealer.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, dealers);
                fs.Close();
                dealSerialized = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealSerialized;
        }
        public static List<Dealer> DeSerializeDealer()
        {
            List<Dealer> des = null;
            try
            {
                FileStream fs = new FileStream("dealer.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Dealer>;
                fs.Close();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return des;
        }
        public static bool AddProduct(Product prod)
        {
            bool prodAdded = false;
            try
            {
                products.Add(prod);
                prodAdded = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodAdded;
        }
        public static bool UpdateProduct(Product prod)
        {
            bool prodUpdated = false;
            try
            {
                for (int i = 0; i < products.Count; i++)
                {
                    if (products[i].ProductId == prod.ProductId)
                    {
                        products[i].ProductName = prod.ProductName;
                        products[i].Quantity = prod.Quantity;
                        products[i].Price = prod.Price;
                        products[i].DateandTimeofProductAdded = prod.DateandTimeofProductAdded;
                        prodUpdated = true;
                    }
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodUpdated;
        }
        public static bool DeleteProduct(int ProdId)
        {
            bool prodDeleted = false;
            try
            {
                Product prod = products.Find(s => s.ProductId == ProdId);
                if (prod != null)
                {
                    products.Remove(prod);
                    prodDeleted = true;
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodDeleted;
        }
        public static Product SearchProduct(int ProdId)
        {
            Product prod = null;
            try
            {
                prod = products.Find(s => s.ProductId == ProdId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prod;
        }
        public static List<Product> RetrieveProducts()
        {
            return products;
        }
        public static bool SerializeProduct()
        {
            bool prodSerialized = false;
            try
            {
                FileStream fs = new FileStream("product.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, products);
                fs.Close();
                prodSerialized = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodSerialized;
        }
        public static List<Product> DeSerializeProduct()
        {
            List<Product> des = null;
            try
            {
                FileStream fs = new FileStream("product.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Product>;
                fs.Close();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return des;
        }
        public static ProductOrder SearchOrder(int OrderId)
        {
            ProductOrder searchOrder = null;
            try
            {
                for (int i = 0; i < orders.Count; i++)
                {
                    ProductOrder productorder = orders[i];
                    if (productorder.OrderId ==OrderId)
                    {
                        searchOrder = orders[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return searchOrder;
        }
        public static bool CancelOrder(int cancelOrderId)
        {
            bool orderCancelled = false;
            try
            {
                ProductOrder productorder = orders.Find(productorders => productorders.ProductId == cancelOrderId);

                if (productorder != null)
                {
                    orders.Remove(productorder);
                    orderCancelled = true;
                    
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return orderCancelled;
        }
        public static bool CancelOrderbyCustomer(int cancelOrderIdbyCustomer)
        {
            bool orderCancelledbyCustomer = false;
            try
            {
                ProductOrder productorder = orders.Find(productorders => productorders.ProductId == cancelOrderIdbyCustomer);
                if (productorder != null)
                {
                    orders.Remove(productorder);
                    orderCancelledbyCustomer = true;
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return orderCancelledbyCustomer;
        }

        public static bool CancelOrderbyDealer(int cancelOrderIdByDealer)
        {
            bool orderCancelledByDealer = false;
            try
            {
                ProductOrder productorder = orders.Find(productorders => productorders.ProductId == cancelOrderIdByDealer);
                if (productorder != null)
                {
                    orders.Remove(productorder);
                    orderCancelledByDealer = true;                  
                }          
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return orderCancelledByDealer;
        }

        public static List<ProductOrder> GetAllOrders()
        {
            return orders;
        }

        public static bool PlaceOrder(ProductOrder productOrder)
        {
            bool orderPlaced = false;
            try
            {
               orders.Add(productOrder);
                orderPlaced = true;              
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
            return orderPlaced;
        }
    }
}


