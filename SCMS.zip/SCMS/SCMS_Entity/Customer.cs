﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCMS_Entity
{
    [Serializable]

    public class Customer

    {
        public int CustomerId { get; set; }

        public string OrganizationName { get; set; }

        public string ContactPerson { get; set; }

        public string ContactNumber { get; set; }

        public string DeliveryAddress { get; set; }

        public string OfficialEmail { get; set; }

    }

}