﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCMS_BAL;
using SCMS_Entity;
using SCMS_Exception;

namespace SCMS
{
    class Program
    {
        static void Main(string[] args)
        {
            MainMenu();
        }
            private static void MainMenu()
            {
                int select;
            do
            {
                Select();
                select = Convert.ToInt32(Console.ReadLine());
                switch (select)
                {
                    case 1:
                        Login();
                        break;
                    case 2:
                        DealerRegistration();
                        break;
                    case 3:
                        CustomerRegistration();
                        break; 
                    case 4:
                        return;
                    default:
                        break;
                }

            } while ((select > 0 && select < 4));
        }

        private static void Login()
        { 
        int user;
            do
            {       
                 PrintLoginMenu();
                user = Convert.ToInt32(Console.ReadLine());
                switch (user)
                {
                    case 1:
                        Admin();
                        break;
                    case 2:
                        Dealer();                     
                        break;
                    case 3:
                        Customer();
                        break;
                    case 4:              
                        return;
                }
            }
            while (user > 0 && user< 4);
            }

        private static void Admin()
        {
            Console.WriteLine("***********Login***********");
            string username = null;
            string password = null;
            Console.WriteLine("\nEnter Username:");
            username = Console.ReadLine();
            Console.WriteLine("\nEnter Password:");
            password = Console.ReadLine();
            string message = "Welcome " +username;           
            if (username == "Admin" && password == "password")
            {
                Console.WriteLine("\nLogin successful");
                Console.WriteLine(message);
            }
            else
            {
                Console.WriteLine("\nSorry Login is invalid!");
                Environment.Exit(0);
            }
        
        int choice;
            do
            {
                AdminMenu();
        Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddProducts();
                        break;
                    case 2:
                        UpdateProduct();
                        break;
                    case 3:
                        DeleteProduct();
                        break;
                    case 4:
                        SearchProduct();
                        break;
                    case 5:
                        RetrieveProduct();
                        break;
                    case 6:
                        SerializeProduct();
                        break;
                    case 7:
                     DeserializeProduct();
                     break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please make valid choice");
                        break;
                }
}
            while (choice< 0 && choice> 8);
        }
        
        private static void Customer()
        {
            Console.WriteLine("***********Login***********");
            string username = null;
            string password = null;
            Console.WriteLine("\nEnter Username:");
            username = Console.ReadLine();
            Console.WriteLine("\nEnter Password:");
            password = Console.ReadLine();
            string message = "Welcome " + username;
            if (username == "Sujin" && password == "sujin1706")
            {
                Console.WriteLine("\nLogin successful");
                Console.WriteLine(message);
            }
            else if (username == "Vishnu" && password == "vishnu1998")
            {
                Console.WriteLine("\nLogin successful");
                Console.WriteLine(message);
            }           
            else
            {
                Console.WriteLine("\nSorry Login is invalid!");
                Environment.Exit(0);
            }

            int choice;
            do
            {
                CustomerMenu();

                Console.Write("Enter your Choice :");
                choice = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        GetAllProducts();
                        break;
                    case 2:
                        SearchProduct();
                        break;
                    case 3:
                        PlaceOrder();
                        break;
                    case 4:
                        SearchOrder();
                        break;
                    case 5:
                        CancelOrder();
                        break;
                    case 6:                       
                        return;                  
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 6));
        }
        private static void Dealer()
        {
            Console.WriteLine("***********Login***********");
            string username = null;
            string password = null;
            Console.WriteLine("\nEnter Username:");
            username = Console.ReadLine();
            Console.WriteLine("\nEnter Password:");
            password = Console.ReadLine();
            string message = "Welcome " + username;
            if (username == "Sujin" && password == "sujin1706")
            {
                Console.WriteLine("\nLogin successful");
                Console.WriteLine(message);
            }
            else if (username == "Vishnu" && password == "vishnu1998")
            {
                Console.WriteLine("\nLogin successful");
                Console.WriteLine(message);
            }           
            else
            {
                Console.WriteLine("\nSorry Login is invalid!");
                Environment.Exit(0);
            }

            int choice;
            do
            {
                DealerMenu();

                Console.Write("Enter your Choice :");
                choice = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine();
                switch (choice)
                {                                           
                    case 1:
                        AddProducts();                       
                        break;
                    case 2:
                        UpdateProduct();
                        break;
                    case 3:
                        DeleteProduct();
                        break;
                    case 4:
                        SearchProduct();
                        break;
                    case 5:
                        SearchOrder();
                        break;
                    case 6 :
                        GetAllProducts();
                        break;
                    case 7:
                        GetAllOrders();
                        break;
                    case 8:
                        CancelOrder();
                        break;
                    case 9:
                        return;
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 6));
        }
        private static void Select()
              {
               Console.WriteLine("\n***********Select Menu***********");
               Console.WriteLine("1)Login ");
               Console.WriteLine("2)Register As Dealer");
               Console.WriteLine("3)Register As Customer");              
              }
          private static void PrintLoginMenu()
             {
         Console.WriteLine("\n***********Login Menu***********");
         Console.WriteLine("1)Admin Login");
         Console.WriteLine("2)Dealer Login");
         Console.WriteLine("3)Customer Login");        
          }
        private static void AdminMenu()
        {
            Console.WriteLine("\n***********Admin Menu***********");
            Console.WriteLine("1) Add Product");
            Console.WriteLine("2) Update Product");
            Console.WriteLine("3) Delete Product");
            Console.WriteLine("4) Search Product");
            Console.WriteLine("5) Get all Products");
            Console.WriteLine("6) Get all Dealers");
            Console.WriteLine("7) Get all Customers");
            Console.WriteLine("8) Search Order");
            Console.WriteLine("9) Serialize Product");
            Console.WriteLine("10) Deserialize Product");
            Console.WriteLine("11) Get all Orders");
            Console.WriteLine("12) Exit");
            Console.WriteLine("**************************");
        }
        private static void CustomerMenu()
        {
            Console.WriteLine("\n***********Customer Menu***********");
            Console.WriteLine("1) Get all Products");           
            Console.WriteLine("2) Search Products");
            Console.WriteLine("3) Place Order");
            Console.WriteLine("4) Search Order");
            Console.WriteLine("5) Cancel Order");
            Console.WriteLine("6) Exit");
            Console.WriteLine("**************************");
        }
        private static void DealerMenu()
        {
            Console.WriteLine("\n*********** Dealer Menu***********");
            Console.WriteLine("1. Add Product ");
            Console.WriteLine("2. Update Product ");
            Console.WriteLine("3. Delete Product");
            Console.WriteLine("4. Search Product");
            Console.WriteLine("5. Search Order");
            Console.WriteLine("6. Get all Products");
            Console.WriteLine("7. Get all orders");
            Console.WriteLine("8. Search Order");
            Console.WriteLine("9. Exit");

        }

        //public static List<Customer> customers = new List<Customer>();
        public static void CustomerRegistration()
        {
            Customer customer = new Customer();
            try
            {
                Console.Write("Enter Customer ID : ");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                customer.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                customer.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                customer.ContactNumber = Console.ReadLine();

                Console.Write("Enter Delivery Address : ");
                customer.DeliveryAddress = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                customer.OfficialEmail = Console.ReadLine();

                bool customerAdded = Bal.AddCustomer(customer);
                if (customerAdded)
                {
                    Console.WriteLine("Customer Added Successfully");
                }
                else

                    throw new SCMSException("Customer Details not Added");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

       

         public static List<Dealer> dealers = new List<Dealer>();

        public static void DealerRegistration()
        {
            Dealer deal = new Dealer();
            try
            {
                Console.Write("Enter Dealer code : ");
                deal.DealerCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                deal.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                deal.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                deal.ContactNumber = Console.ReadLine();

                Console.Write("Enter Delivery Address : ");
                deal.DeliveryAddress = Console.ReadLine();

                Console.Write("Enter Warehouse Address : ");
                deal.WarehouseAddress = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                deal.OfficialEmail = Console.ReadLine();

                bool dealAdded = Bal.AddDealer(deal);
                if (dealAdded)
                {
                    Console.WriteLine("Dealer Added Successfully");
                }
                else

                    throw new SCMSException("Dealer Details not Added");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        

       public static List<Product> products = new List<Product>();
       
        public static void AddProducts()
        {
            Product prod = new Product();
            try
            {
                Console.Write("Enter Product ID : ");
                prod.ProductId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Product Name : ");
                prod.ProductName = Console.ReadLine();

                Console.Write("Enter Quantity : ");
                prod.Quantity = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Price: ");
                prod.Price = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Date and Time of Product Added : " + DateTime.Now);
                prod.DateandTimeofProductAdded = DateTime.Now;
                
                bool prodAdded = Bal.AddProduct(prod);
                if (prodAdded)
                {
                    Console.WriteLine("Product Added Successfully");
                }
                else

                    throw new SCMSException("Product Details not Added");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void UpdateProduct()
        {
            Product prod = new Product();
            try
            {
                Console.Write("Enter Product ID to be Updated : ");
                prod.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product Name to be Updated : ");
                prod.ProductName = Console.ReadLine();
                Console.Write("Enter Quantity to be Updated: ");
                prod.Quantity = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Price to be Updated: ");
                prod.Price = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Date and Time of Product Added : ");
                prod.DateandTimeofProductAdded = Convert.ToDateTime(Console.ReadLine());

                bool prodUpdated = Bal.UpdateProduct(prod);
                if (prodUpdated)
                {
                    Console.WriteLine("/nProduct Updated Successfully");
                }
                else
                    throw new SCMSException("Product Details not Updated");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteProduct()
        {
            int id;
            try
            {
                Console.Write("Enter Product ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool proddeleted = Bal.DeleteProduct(id);
                if (proddeleted)
                {
                    Console.WriteLine("Product Deleted Successfully");
                }
                else
                    throw new SCMSException("Product not deleted");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchProduct()
        {
            int id;
            Product prod = null;
            try
            {
                Console.Write("Enter Product ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                prod = Bal.SearchProduct(id);
                if (prod != null)
                {
                    Console.WriteLine("Product ID : " + prod.ProductId);
                    Console.WriteLine("Product Name : " + prod.ProductName);
                    Console.WriteLine("Quantity : " + prod.Quantity);
                    Console.WriteLine("Price: " + prod.Price);
                    Console.WriteLine("DateTime : " + prod.DateandTimeofProductAdded);
                }
                else
                    throw new SCMSException("Product not found");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveProduct()
        {
            try
            {
                List<Product> prodList = Bal.GetProducts();
                if (prodList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Product ID Product Name Quantity Price DateandTimeofProductAdded   ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Product prod in prodList)
                    {
                        Console.WriteLine($"{prod.ProductId} \t {prod.ProductName} \t {prod.Quantity} \t {prod.Price} \t {prod.DateandTimeofProductAdded}   ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Product Details not Available");
                }
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeProduct()
        {
            try
            {
                bool prodSerialized = Bal.SerializeProduct();
                if (prodSerialized)
                {
                    Console.WriteLine("Product details serialized successfully");
                }
                else
                {
                    throw new SCMSException("Product Details not Serialized");
                }
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeProduct()
        {
            try
            {
                List<Product> prodList = Bal.DeserializeProduct();
                if (prodList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Product ID    Product Name   Quantity   Price  DateandTimeofProductAdded  ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Product prod in prodList)
                    {
                        Console.WriteLine($"{prod.ProductId}\t{prod.ProductName}\t{prod.Quantity}\t {prod.Price}\t {prod.DateandTimeofProductAdded}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Dealer Details not Deserialized");
                }
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void GetAllProducts()
        {
            try
            {
                List<Product> prod = Bal.GetProducts();
                if (prod.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("ProductId ProductName Quantity Price DateandTimeofProductAdded ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Product product in prod)
                    {
                        Console.WriteLine($"{product.ProductId} \t {product.ProductName} \t {product.Quantity} \t {product.Price} \t {product.DateandTimeofProductAdded} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Product Details not Available");
                }
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void GetAllOrders()
        {
            try
            {
                List<ProductOrder> orders = Bal.GetAllOrders();
                if (orders.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("OrderId ProductId ExpectedDeliveryDate CustomerId DealerCode DispatchedStatus ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (ProductOrder productorder in orders)
                    {
                        Console.WriteLine($"{productorder.OrderId} \t {productorder.ProductId} \t {productorder.ExpectedDeliveryDate} \t {productorder.CustomerId} \t {productorder.DealerCode} \t {productorder.DispatchedStatus} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("ProductOrder Details not Available");
                }
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PlaceOrder()
        {
            ProductOrder product  = new ProductOrder();
            try
            {
                Console.Write("Enter Order Id: ");
                product.OrderId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Product Id: ");
                product.ProductId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter ExpectedDeliveryDate : ");
                product.ExpectedDeliveryDate = DateTime.FromOADate(7);

                Console.Write("Enter Customer Id: ");
                product.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Dealer Code: ");
                product.DealerCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter DispatchedStatus : ");
                product.DispatchedStatus = Console.ReadLine();

                bool orderPlaced = Bal.PlaceOrder(product);
                if (orderPlaced)
                {
                    Console.WriteLine("Product Order Placed Successfully");
                }
                else

                    throw new SCMSException("Product  Order Cannot be Placed");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void CancelOrder()
        {
            try
            {
                int id;
                Console.Write("Enter ProductOrder ID to be Cancelled : ");
                id = Convert.ToInt32(Console.ReadLine());
                ProductOrder product = Bal.SearchOrder(id);
                if (product != null)
                {
                    bool orderCancel = Bal.CancelOrder(id);
                    if (orderCancel)
                    {
                        Console.WriteLine("Product Order Cancelled Successfully (By Admin)");
                    }
                    else
                    {
                        throw new SCMSException("Unable To Cancel Product Order (By Admin)");
                    }
                }
                else
                {
                    throw new SCMSException("No productOrder Details found");
                }
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchOrder()
        {
            int id;
            ProductOrder productorder = null;
            try
            {
                Console.Write("Enter ProductOrder ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                productorder = Bal.SearchOrder(id);
                if (productorder != null)
                {
                    Console.WriteLine("ProductOrderId : " + productorder.OrderId);
                    Console.WriteLine("ProductId : " + productorder.ProductId);
                    Console.WriteLine("ExpectedDeliveryDate : " + productorder.ExpectedDeliveryDate);
                    Console.WriteLine("CustomerId : " + productorder.CustomerId);
                    Console.WriteLine("DealerCode : " + productorder.DealerCode);
                    Console.WriteLine("DispatchedStatus: " + productorder.DispatchedStatus);

                    //Console.WriteLine("UserName : " + customer.Username);
                    //Console.WriteLine("Password : " + customer.Password);
                }
                else
                    throw new SCMSException("Product not found");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    }
    
    







