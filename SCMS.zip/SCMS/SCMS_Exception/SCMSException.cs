﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCMS_Exception
{
    public class SCMSException : ApplicationException
    {
        public SCMSException() : base()
        {

        }
        public SCMSException(string message) : base(message)
        {

        }
        public SCMSException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
