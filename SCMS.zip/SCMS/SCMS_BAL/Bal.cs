﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCMS_DAL;
using SCMS_Entity;
using SCMS_Exception;
using System.Text.RegularExpressions;

namespace SCMS_BAL
{
    public class Bal
    {

        private static bool ValidateCustomer(Customer customer)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();

            //bool isUsername = Regex.IsMatch(customer.Username, "^[a-zA-Z0-9]*$");
            //if (!isUsername)
            //{
            //    errorMessages.Append("\nUsername must contain string!");
            //}
            //bool isPassword = Regex.IsMatch(customer.Password, "^[a-zA-Z0-9]*$");
            //if (!isPassword)
            //{
            //    errorMessages.Append("\nPassword must contain integer!");
            //}
            bool isCustomerId = Regex.IsMatch(customer.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("\nCustomer ID must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isName = Regex.IsMatch(customer.OrganizationName, "^[A-Z][a-z]");
            //if (!isName)
            //{
            //    errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
            //    Valid = false;
            //}
            //bool isContactPersonName = Regex.IsMatch(customer.ContactPerson, "^[A-Z][a-z]");
            //if (!isContactPersonName)
            //{
            //    Valid = false;
            //    errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            //}
            bool isContactNo = Regex.IsMatch(customer.ContactNumber.ToString(), "^[0-9]{10}$");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("\nContact No must be of 10 digits!");
            }
            //bool isDeliveryAddress = Regex.IsMatch(customer.DeliveryAddress, "^[A-Z][a-z]");
            //if (!isDeliveryAddress)
            //{
            //    errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
            //    Valid = false;
            //}
            bool isOfficialEmail = Regex.IsMatch(customer.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isOfficialEmail)
            {
                errorMessages.Append("\nEmail is Invalid!" + Environment.NewLine);
                Valid = false;
            }
            if (!Valid) { throw new SCMSException(errorMessages.ToString()); }
            return Valid;
        } 

    private static bool ValidateDealer(Dealer deal)
    {
        bool Valid = true;
        StringBuilder errorMessages = new StringBuilder();
        bool isDealerCode = Regex.IsMatch(deal.DealerCode.ToString(), "^[0-9]{1,5}$");
        if (!isDealerCode)
        {
            errorMessages.Append("\nDealer code must contain not more than 5 digits!");
            Valid = false;
        }
        //bool isOrganizationName = Regex.IsMatch(deal.OrganizationName, "^[A-Z][a-z]");
        //if (!isOrganizationName)
        //{
        //    errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
        //    Valid = false;
        //}
        //bool isContactPerson = Regex.IsMatch(deal.ContactPerson, "^[A-Z][a-z]");
        //if (!isContactPerson)
        //{
        //    Valid = false;
        //    errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
        //}
        bool isContactNo = Regex.IsMatch(deal.ContactNumber.ToString(), "^[0-9]{10}$");
        if (!isContactNo)
        {
            Valid = false;
            errorMessages.Append("\nContact No must be of 10 digits!");
        }
        //bool isDeliveryAddress = Regex.IsMatch(deal.DeliveryAddress, "^[A-Z][a-z]");
        //if (!isDeliveryAddress)
        //{
        //    errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
        //    Valid = false;
        //}
        //    bool isWarehouseAddress = Regex.IsMatch(deal.WarehouseAddress, "^[A-Z][a-z]");
        //    if (!isWarehouseAddress)
        //    {
        //        errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
        //        Valid = false;
        //    }
        bool isOfficialEmail = Regex.IsMatch(deal.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        if (!isOfficialEmail)
        {
            errorMessages.Append("\nEmail is Invalid!" + Environment.NewLine);
            Valid = false;
        }
        if (!Valid) { throw new SCMSException(errorMessages.ToString()); }
        return Valid;
    }

        private static bool ValidateProduct(Product prod)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isProductId = Regex.IsMatch(prod.ProductId.ToString(), "^[0-9]{1,5}$");
            if (!isProductId)
            {
                errorMessages.Append("\nProduct ID must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isProductName = Regex.IsMatch(prod.ProductName, "^[A-Z][a-z]");
            //if (!isProductName)
            //{
            //    errorMessages.Append(Environment.NewLine + "Product Name Should Start with Capital Letter");
            //    Valid = false;
            //}
            bool isQuantity = Regex.IsMatch(prod.Quantity.ToString(), "^[0-9]");
            if (!isQuantity)
            {
                Valid = false;
                errorMessages.Append(Environment.NewLine + "Quantity must be integer!");
            }
            bool isPrice = Regex.IsMatch(prod.Price.ToString(), "^[0-9]");
            if (!isPrice)
            {
                Valid = false;
                errorMessages.Append("\nrice must be integer!");
            }
            if (prod.DateandTimeofProductAdded >= DateTime.Now)
            {
                Valid = false;
                errorMessages.Append("\nDate time must be given properly!");
            }

            if (!Valid)
            {
                throw new SCMSException(errorMessages.ToString());
            }
            return Valid;
        }
        private static bool ValidateProductOrder(ProductOrder productorder)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isProductOrderId = Regex.IsMatch(productorder.OrderId.ToString(), "^[0-9]{1,4}$");
            if (!isProductOrderId)
            {
                errorMessages.Append("ProductOrder ID must contain not more than 4 digits!");
                Valid = false;
            }
            bool isProductId = Regex.IsMatch(productorder.ProductId.ToString(), "^[0-9]{1,3}$");
            if (!isProductId)
            {
                errorMessages.Append("Product ID must contain not more than 3 digits!");
                Valid = false;
            }
            bool isCustomerId = Regex.IsMatch(productorder.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("CustomerId must contain not more than 5 digits!");
                Valid = false;
            }
            bool isDealerCode = Regex.IsMatch(productorder.DealerCode.ToString(), "^[0-9]{1,5}$");
            if (!isDealerCode)
            {
                errorMessages.Append("DealerCode must contain not more than 5 digits!");
                Valid = false;
            }

            //bool isExpectedDeliveryDate = Regex.IsMatch(productorder.ExpectedDeliveryDate, "^[0 - 3][0 - 9]/[0 - 1][0 - 9]/[0 - 9]{ 4} [0-1] [0-9]:[0-5] [0-9]:[0-5] [0-9] [paPA] [Mm]$");
            //if (!isExpectedDeliveryDate)
            //{
            //    errorMessages.Append("Invalid date and time" + Environment.NewLine);
            //    Valid = false;
            //}

            ////bool isUsername = Regex.IsMatch(productorder.Username, "^([A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            ////if (!isUsername)
            ////{
            ////    errorMessages.Append(Environment.NewLine + "Username must start with a letter and should contain minimum of 5 characters");
            ////    Valid = false;
            ////}

            ////bool isPassword = Regex.IsMatch(productorder.Password, "^(?=.*[A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            ////if (!isPassword)
            ////{
            ////    errorMessages.Append(Environment.NewLine + "Password Should contain minimum 5 characters, atleast one letter , one number and one special character");
            ////    Valid = false;
            ////}

            if (productorder.DispatchedStatus == string.Empty)
            {
                errorMessages.Append("DispatchedStatus should be provided\n");
                Valid = false;
            }

            if (!Valid == false)
            {
                throw new SCMSException(errorMessages.ToString());
            }
            return Valid;
        }

        //Customer Details
        public static bool RegisterAsCustomer(Customer customer)
        {
            bool custRegistered = false;

            try
            {
                if (ValidateCustomer(customer))
                {
                    custRegistered = Dal.RegisterAsCustomer(customer);
                    custRegistered = true;
                }
                else
                    throw new SCMSException("Customer data is invalid");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custRegistered;
        }
        public static bool AddCustomer(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                if (ValidateCustomer(customer))
                {
                    Dal Dal = new Dal();
                    customerAdded = Dal.AddCustomer(customer);
                    customerAdded = true;
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerAdded;
        }

        public static bool UpdateCustomer(Customer customer)
        {
            bool customerUpdated = false;
            try
            {
                if (ValidateCustomer(customer))
                {
                    Dal Dal = new Dal();
                    customerUpdated = Dal.UpdateCustomer(customer);
                    customerUpdated = true;
                }
                else
                    throw new SCMSException("Please provide valid Customer details for update");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerUpdated;
        }

        public static bool DeleteCustomer(int CustId)
        {
            bool customerDeleted = false;
            try
            {
                Dal Dal = new Dal();
                customerDeleted = Dal.DeleteCustomer(CustId);
                customerDeleted = true;
            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }

        public static Customer SearchCustomer(int CustId)
        {
            Customer customer = null;
            try
            {
                Dal Dal = new Dal();
                customer = Dal.SearchCustomer(CustId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customer;
        }

        public static List<Customer> RetrieveCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.RetrieveCustomer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static bool SerializeCustomer()
        {
            bool customerSerialized = false;
            try
            {
                customerSerialized = Dal.SerializeCustomer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerSerialized;
        }
        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.DeSerializeCustomer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return customerList;
        }
        public static bool CancelProductOrderCustomer(int cancelOrderId)
        {
            bool orderCancelledbycustomer = false;
            try
            {

                orderCancelledbycustomer = Dal.CancelOrderbyCustomer(cancelOrderId);
                orderCancelledbycustomer = true;
            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return orderCancelledbycustomer;
        }
        //Dealer Details    
        public static bool RegisterAsDealer(Dealer dealer)
        {
            bool dealRegistered = false;

            try
            {
                if (ValidateDealer(dealer))
                {
                    dealRegistered = Dal.RegisterAsDealer(dealer);
                    dealRegistered = true;
                }
                else
                    throw new SCMSException("Dealer data is invalid");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dealRegistered;
        }        
        public static bool AddDealer(Dealer deal)
        {
            bool dealAdded = false;
            try
            {
                if (ValidateDealer(deal))
                {
                    Dal Dal = new Dal();
                    dealAdded = Dal.AddDealer(deal);
                    dealAdded = true;
                }
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealAdded;
        }
        public static bool UpdateDealer(Dealer deal)
        {
            bool dealUpdated = false;
            try
            {
                if (ValidateDealer(deal))
                {
                    Dal Dal = new Dal();
                    dealUpdated = Dal.UpdateDealer(deal);
                    dealUpdated = true;
                }
                else
                    throw new SCMSException("Please provide valid Dealer details for update");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealUpdated;
        }
        public static bool DeleteDealer(int DealId)
        {
            bool dealDeleted = false;
            try
            {
                Dal Dal = new Dal();
                dealDeleted = Dal.DeleteDealer(DealId);
                dealDeleted = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealDeleted;
        }
        public static Dealer SearchDealer(int DealId)
        {
            Dealer deal = null;
            try
            {
                Dal Dal = new Dal();
                deal = Dal.SearchDealer(DealId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return deal;
        }
        public static List<Dealer> RetrieveDealer()
        {
            List<Dealer> dealList = null;
            try
            {
                dealList = Dal.RetrieveDealer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealList;
        }
        public static bool SerializeDealer()
        {
            bool dealSerialized = false;
            try
            {
                dealSerialized = Dal.SerializeDealer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealSerialized;
        }
        public static List<Dealer> DeserializeDealer()
        {
            List<Dealer> dealList = null;
            try
            {
                dealList = Dal.DeSerializeDealer();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return dealList;
        }
        public static bool CancelOrderDealer(int cancelOrderId)
        {
            bool orderCancelledbyDealer = false;
            try
            {
                orderCancelledbyDealer = Dal.CancelOrderbyDealer(cancelOrderId);
                orderCancelledbyDealer = true;
            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return orderCancelledbyDealer;
        }



        //Product Details
        
        public static bool AddProduct(Product prod)
        {
            bool prodAdded = false;
            try
            {
                if (ValidateProduct(prod))
                {
                    prodAdded = Dal.AddProduct(prod);
                    prodAdded = true;
                }
            }
            catch (SCMSException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodAdded;
        }
        public static bool UpdateProduct(Product prod)
        {
            bool prodUpdated = false;
            try
            {
                if (ValidateProduct(prod))
                {
                    Dal Dal = new Dal();
                    prodUpdated = Dal.UpdateProduct(prod);
                    prodUpdated = true;
                }
                else
                    throw new SCMSException("Please provide valid Product details for update");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodUpdated;
        }
        public static bool DeleteProduct(int ProdId)
        {
            bool prodDeleted = false;
            try
            {
                Dal Dal = new Dal();
                prodDeleted = Dal.DeleteProduct(ProdId);
                prodDeleted = true;
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodDeleted;
        }
        public static Product SearchProduct(int ProdId)
        {
            Product prod = null;
            try
            {
                Dal Dal = new Dal();
                prod = Dal.SearchProduct(ProdId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prod;
        }
        
        public static List<Product> GetProducts()
        {
            List<Product> prodList = null;
            try
            {
                prodList = Dal.RetrieveProducts();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodList;
        }
        public static bool SerializeProduct()
        {
            bool prodSerialized = false;
            try
            {
                prodSerialized = Dal.SerializeProduct();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodSerialized;
        }
        public static List<Product> DeserializeProduct()
        {
            List<Product> prodList = null;
            try
            {
                prodList = Dal.DeSerializeProduct();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            return prodList;
        }

        //Order Details
        public static ProductOrder SearchOrder(int OrderId)
        {
            ProductOrder productorder = null;
            try
            {
                productorder = Dal.SearchOrder(OrderId);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorder;
        }

        public static List<ProductOrder> GetAllOrders()
        {
            List<ProductOrder> orderList = null;
            try
            {
                orderList = Dal.GetAllOrders();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return orderList;
        }
        public static bool PlaceOrder(ProductOrder productOrder)
        {
            bool orderPlaced = false;
            try
            {
                if (ValidateProductOrder(productOrder))
                {
                    orderPlaced = Dal.PlaceOrder(productOrder);
                    orderPlaced = true;
                }
            }
            catch (SCMSException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return orderPlaced;
        }
        public static bool CancelOrder(int cancelOrderId)
        {
            bool orderCancelled = false;
            try
            {
                orderCancelled = Dal.CancelOrder(cancelOrderId);
                orderCancelled = true;
            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return orderCancelled;
        }


    }
}


